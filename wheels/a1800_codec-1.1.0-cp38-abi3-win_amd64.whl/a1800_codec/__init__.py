from .a1800_codec import *

__doc__ = a1800_codec.__doc__
if hasattr(a1800_codec, "__all__"):
    __all__ = a1800_codec.__all__